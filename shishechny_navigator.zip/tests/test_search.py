import sys
import types
import unittest

# Search logic has no Telegram runtime dependency; stub imports for local unit tests.
telegram = types.ModuleType("telegram")
telegram.Update = type("Update", (), {"ALL_TYPES": []})
telegram.constants = types.ModuleType("telegram.constants")
telegram.constants.ChatType = type("ChatType", (), {"PRIVATE": "private"})
telegram.constants.ParseMode = type("ParseMode", (), {"HTML": "HTML"})
telegram.ext = types.ModuleType("telegram.ext")
for name in ("Application", "CommandHandler", "ContextTypes", "MessageHandler", "filters"):
    setattr(telegram.ext, name, type(name, (), {}))
sys.modules["telegram"] = telegram
sys.modules["telegram.constants"] = telegram.constants
sys.modules["telegram.ext"] = telegram.ext

from bot import normalize_record, search_records, records_from_json


class SearchTests(unittest.TestCase):
    def setUp(self):
        self.records = [
            normalize_record({
                "title": "Городской транспорт",
                "text": "Развитие общественного транспорта и трамвайных линий",
                "url": "https://t.me/example/1",
                "channel": "@example",
            }, "test.json"),
            normalize_record({
                "title": "Климат и энергия",
                "text": "Энергетическая политика и климатические цели",
                "url": "https://t.me/example/2",
            }, "test.json"),
        ]

    def test_finds_matching_post(self):
        results = search_records(self.records, "общественный транспорт")
        self.assertTrue(results)
        self.assertIn("транспорт", results[0][1]["searchable"].lower())

    def test_empty_query(self):
        self.assertEqual(search_records(self.records, "!!!"), [])

    def test_json_wrapper(self):
        result = records_from_json({"posts": [{"title": "A", "text": "B"}]}, "x.json")
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["title"], "A")


if __name__ == "__main__":
    unittest.main()
