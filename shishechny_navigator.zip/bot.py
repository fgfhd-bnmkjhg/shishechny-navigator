import asyncio
import csv
import html
import json
import logging
import os
import re
import zipfile
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from telegram import Update
from telegram.constants import ChatType, ParseMode
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("ARCHIVE_DIR", BASE_DIR / "data"))
SUPPORTED = {".json", ".jsonl", ".csv", ".tsv", ".txt", ".html", ".htm"}
MAX_RESULTS = max(1, min(int(os.getenv("MAX_RESULTS", "5")), 10))
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=os.getenv("LOG_LEVEL", "INFO"),
)
log = logging.getLogger("shishechny-navigator")

URL_RE = re.compile(r"https?://[^\s<>\"']+", re.I)
TAG_RE = re.compile(r"<[^>]+>")
WORD_RE = re.compile(r"[^\W_]+", re.UNICODE)


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    text = str(value)
    text = TAG_RE.sub(" ", text)
    return re.sub(r"\s+", " ", html.unescape(text)).strip()


def pick(record: dict, names: tuple[str, ...]) -> str:
    lower_map = {str(k).strip().lower(): v for k, v in record.items()}
    for name in names:
        if name in lower_map and lower_map[name] not in (None, ""):
            return clean_text(lower_map[name])
    return ""


def normalize_record(record: Any, source: str) -> dict | None:
    if not isinstance(record, dict):
        return None
    title = pick(record, ("title", "name", "headline", "subject"))
    body = pick(record, ("text", "message", "content", "body", "caption", "description", "post"))
    url = pick(record, ("url", "link", "permalink", "post_url", "original_url"))
    channel = pick(record, ("channel", "source", "author", "username", "telegram_channel"))
    date = pick(record, ("date", "datetime", "timestamp", "published_at", "created_at"))
    # Telegram export commonly stores links in a "text_entities" or "text" field.
    if isinstance(record.get("text"), list):
        body = clean_text(" ".join(
            str(x.get("text", "")) if isinstance(x, dict) else str(x)
            for x in record["text"]
        ))
    if not url:
        for value in record.values():
            if isinstance(value, str):
                match = URL_RE.search(value)
                if match:
                    url = match.group(0).rstrip(".,);]")
                    break
    if not body and not title:
        return None
    if url and not urlparse(url).scheme in ("http", "https"):
        url = ""
    searchable = " ".join(x for x in (title, body, channel, date) if x).strip()
    return {
        "title": title or (body[:90] + ("…" if len(body) > 90 else "")),
        "text": body,
        "url": url,
        "channel": channel or source,
        "date": date,
        "searchable": searchable,
        "source_file": source,
    }


def records_from_json(data: Any, source: str) -> list[dict]:
    if isinstance(data, list):
        items = data
    elif isinstance(data, dict):
        # Common wrappers in archive exports.
        for key in ("posts", "messages", "items", "results", "publications", "data"):
            if isinstance(data.get(key), list):
                items = data[key]
                break
        else:
            # Telegram Desktop export may nest messages in chats.list.
            chats = data.get("chats")
            if isinstance(chats, dict) and isinstance(chats.get("list"), list):
                items = [m for chat in chats["list"] for m in chat.get("messages", [])]
            else:
                items = [data]
    else:
        return []
    result = []
    for item in items:
        record = normalize_record(item, source)
        if record:
            result.append(record)
    return result


def load_file(path: Path) -> list[dict]:
    suffix = path.suffix.lower()
    result: list[dict] = []
    try:
        if suffix == ".json":
            result.extend(records_from_json(json.loads(path.read_text(encoding="utf-8-sig")), path.name))
        elif suffix == ".jsonl":
            for line in path.read_text(encoding="utf-8-sig").splitlines():
                if line.strip():
                    try:
                        result.extend(records_from_json(json.loads(line), path.name))
                    except json.JSONDecodeError:
                        log.warning("Skipping invalid JSONL line in %s", path.name)
        elif suffix in (".csv", ".tsv"):
            delimiter = "\t" if suffix == ".tsv" else ","
            with path.open(encoding="utf-8-sig", newline="") as f:
                for row in csv.DictReader(f, delimiter=delimiter):
                    record = normalize_record(row, path.name)
                    if record:
                        result.append(record)
        elif suffix == ".txt":
            for block in re.split(r"\n\s*\n", path.read_text(encoding="utf-8-sig")):
                block = block.strip()
                if not block:
                    continue
                match = URL_RE.search(block)
                record = normalize_record(
                    {"text": block, "url": match.group(0).rstrip(".,);]") if match else ""},
                    path.name,
                )
                if record:
                    result.append(record)
        elif suffix in (".html", ".htm"):
            raw = path.read_text(encoding="utf-8-sig", errors="replace")
            # Keep HTML parsing dependency-free; split on likely post containers.
            chunks = re.split(r"(?i)</(?:article|li|div|p)\s*>", raw)
            for chunk in chunks:
                text = clean_text(chunk)
                if len(text) < 15:
                    continue
                match = URL_RE.search(chunk)
                record = normalize_record(
                    {"text": text, "url": match.group(0).rstrip('",);]') if match else ""},
                    path.name,
                )
                if record:
                    result.append(record)
    except (OSError, UnicodeError, json.JSONDecodeError, csv.Error) as exc:
        log.warning("Cannot read %s: %s", path, exc)
    return result


def load_archive() -> list[dict]:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    records: list[dict] = []
    seen: set[tuple[str, str]] = set()
    for path in sorted(DATA_DIR.rglob("*")):
        if not path.is_file() or path.name.startswith("."):
            continue
        if path.suffix.lower() == ".zip":
            try:
                with zipfile.ZipFile(path) as archive:
                    for member in archive.namelist():
                        if Path(member).suffix.lower() not in SUPPORTED or member.endswith("/"):
                            continue
                        try:
                            raw = archive.read(member).decode("utf-8-sig", errors="replace")
                            temp_path = BASE_DIR / ".archive_temp_read_only"
                            suffix = Path(member).suffix.lower()
                            parsed = parse_text_blob(raw, suffix, f"{path.name}:{member}")
                            for item in parsed:
                                key = (item.get("url", ""), item.get("text", ""))
                                if key not in seen:
                                    seen.add(key)
                                    records.append(item)
                        except (KeyError, RuntimeError):
                            continue
            except (OSError, zipfile.BadZipFile) as exc:
                log.warning("Cannot read ZIP %s: %s", path.name, exc)
        elif path.suffix.lower() in SUPPORTED:
            for item in load_file(path):
                key = (item.get("url", ""), item.get("text", ""))
                if key not in seen:
                    seen.add(key)
                    records.append(item)
    return records


def parse_text_blob(raw: str, suffix: str, source: str) -> list[dict]:
    try:
        if suffix == ".json":
            return records_from_json(json.loads(raw), source)
        if suffix == ".jsonl":
            out = []
            for line in raw.splitlines():
                if line.strip():
                    try:
                        out.extend(records_from_json(json.loads(line), source))
                    except json.JSONDecodeError:
                        pass
            return out
        if suffix in (".csv", ".tsv"):
            import io
            reader = csv.DictReader(io.StringIO(raw), delimiter="\t" if suffix == ".tsv" else ",")
            return [r for row in reader if (r := normalize_record(row, source))]
        if suffix in (".txt", ".html", ".htm"):
            if suffix != ".txt":
                raw = clean_text(raw)
            out = []
            for block in re.split(r"\n\s*\n", raw):
                if block.strip():
                    match = URL_RE.search(block)
                    item = normalize_record({"text": block, "url": match.group(0).rstrip(".,);]") if match else ""}, source)
                    if item:
                        out.append(item)
            return out
    except Exception as exc:
        log.warning("Cannot parse %s: %s", source, exc)
    return []


def tokenize(text: str) -> set[str]:
    return {w.casefold() for w in WORD_RE.findall(text) if len(w) > 1}


def search_records(records: list[dict], query: str) -> list[tuple[float, dict]]:
    terms = tokenize(query)
    if not terms:
        return []
    scored = []
    for record in records:
        text = record.get("searchable", "")
        words = tokenize(text)
        if not words:
            continue
        overlap = len(terms & words)
        if overlap == 0:
            continue
        # Coverage matters more than raw document length.
        coverage = overlap / len(terms)
        density = overlap / max(1, len(words) ** 0.5)
        exact_bonus = 0.35 if query.casefold() in text.casefold() else 0
        score = coverage * 2 + density * 0.25 + exact_bonus
        scored.append((score, record))
    scored.sort(key=lambda pair: (pair[0], pair[1].get("date", "")), reverse=True)
    return scored


def format_result(record: dict, index: int) -> str:
    title = html.escape(record.get("title") or "Без названия")
    channel = html.escape(record.get("channel") or "Источник неизвестен")
    date = html.escape(record.get("date") or "")
    body = html.escape(record.get("text") or "")
    if len(body) > 500:
        body = body[:497] + "…"
    lines = [f"<b>{index}. {title}</b>"]
    meta = " · ".join(x for x in (channel, date) if x)
    if meta:
        lines.append(f"<i>{meta}</i>")
    if body:
        lines.append(body)
    url = record.get("url", "")
    if url:
        lines.append(f'<a href="{html.escape(url, quote=True)}">Открыть оригинальный пост</a>')
    else:
        lines.append("<i>Ссылка на оригинал в записи не найдена.</i>")
    return "\n".join(lines)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = (
        "<b>Шишечный навигатор</b>\n\n"
        "Я ищу публикации в архиве и возвращаю ссылки на оригинальные посты.\n\n"
        "Напиши поисковый запрос обычным сообщением или используй:\n"
        "/search слова для поиска\n"
        "/stats — статистика архива\n"
        "/help — помощь"
    )
    await update.effective_message.reply_text(text, parse_mode=ParseMode.HTML)


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_message.reply_text(
        "Отправь ключевые слова, например: <code>городская среда транспорт</code>.\n"
        "Можно искать по нескольким словам. Бот ищет совпадения в тексте, заголовке, "
        "источнике и дате.\n\n"
        "Команды: /search запрос, /stats, /start.\n"
        "Бот использует только файлы из папки data/ или поддерживаемые файлы внутри ZIP. "
        "Он не придумывает ссылки и не ищет публикации за пределами архива.",
        parse_mode=ParseMode.HTML,
    )


async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    records = load_archive()
    with_urls = sum(bool(r.get("url")) for r in records)
    await update.effective_message.reply_text(
        f"Записей в архиве: {len(records)}\n"
        f"Записей со ссылками: {with_urls}\n"
        f"Папка архива: {DATA_DIR}"
    )


async def run_search(update: Update, query: str) -> None:
    message = update.effective_message
    if not query.strip():
        await message.reply_text("Напиши слова для поиска. Пример: /search климат энергетика")
        return
    records = load_archive()
    if not records:
        await message.reply_text(
            "Архив пока пустой или его формат не распознан.\n"
            "Добавь JSON, JSONL, CSV, TSV, TXT, HTML или ZIP с такими файлами в папку data/."
        )
        return
    matches = search_records(records, query)[:MAX_RESULTS]
    if not matches:
        await message.reply_text("Ничего не найдено. Попробуй другие слова.")
        return
    await message.reply_text(f"Найдено совпадений: {len(matches)}")
    for i, (_, record) in enumerate(matches, 1):
        await message.reply_text(
            format_result(record, i),
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=True,
        )


async def search_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await run_search(update, " ".join(context.args))


async def text_search(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.effective_message or not update.effective_message.text:
        return
    message = update.effective_message
    # In groups, respond to commands or messages that mention/reply to the bot.
    if message.chat.type != ChatType.PRIVATE:
        bot_username = (context.bot.username or "").lower()
        is_reply = bool(message.reply_to_message and message.reply_to_message.from_user and
                        message.reply_to_message.from_user.id == context.bot.id)
        is_mention = bot_username and f"@{bot_username}" in message.text.lower()
        if not (is_reply or is_mention):
            return
        query = re.sub(rf"@{re.escape(bot_username)}\b", "", message.text, flags=re.I).strip()
    else:
        query = message.text.strip()
    await run_search(update, query)


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    log.error("Unhandled error: %s", context.error, exc_info=context.error)


def main() -> None:
    if not TOKEN:
        raise SystemExit(
            "Не задан TELEGRAM_BOT_TOKEN. Создай бота через @BotFather и укажи токен в .env."
        )
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("stats", stats))
    app.add_handler(CommandHandler("search", search_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_search))
    app.add_error_handler(error_handler)
    log.info("Starting bot. Archive directory: %s", DATA_DIR)
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
